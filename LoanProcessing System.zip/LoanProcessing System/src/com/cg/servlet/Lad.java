package com.cg.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.loandao.LoanDAO;

/**
 * Servlet implementation class Lad
 */
@WebServlet("/Lad")
public class Lad extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
	LoanDAO dao = new LoanDAO();
		PrintWriter out=response.getWriter();
		String name=request.getParameter("name");
		String dob=request.getParameter("dob");
	    String marital=request.getParameter("maritalstatus");
		String mobile=request.getParameter("mobile");
		String dependencies=request.getParameter("dependencies");
		String email=request.getParameter("email");
		String loan=request.getParameter("loanamount");
		String address=request.getParameter("address");
		String income=request.getParameter("annual");
		String proof=request.getParameter("documents");
		String guarantee=request.getParameter("guarantee");
		System.out.println( guarantee);
		String marketvalue=request.getParameter("market");
		String loanprogram=request.getParameter("loanprogram");
		int x = dao.loandetails(loanprogram,loan, address, income, proof, guarantee, marketvalue);
		if (x>0)
		{
System.out.println("success from loan");

		}
		else
		{
			System.out.println("fail from loan");
		}
		int n = dao.adduserdetails(name, dob, marital, mobile, dependencies, email);
		
		if (n>0)
		{
System.out.println("okay");
		}
		else
		{
			System.out.println("not done");
		}
		String id="";
		try {
			id = dao.getId();
			out.println("<html>");
			out.println("<body>");
			out.println("Your Application_Id is:" + id );
			out.println(" ");
		} catch (SQLException e) {
			
			e.printStackTrace();
		}	
		String interviewdate;
		try {
			interviewdate = dao.getDate(id);
			out.println("<br><br> Your Interview Date is Scheduled On:" + interviewdate);
			out.println("</html>");
			out.println("</body>");
		} catch (SQLException e) {
			
			e.printStackTrace();
		}	
		
	}

}
