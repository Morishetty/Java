package com.cg.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ProgramsServlet
 */
@WebServlet("/ProgramsServlet")
public class ProgramsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String q = request.getParameter("radio");
	     if ("purchase".equals(q)) {
	         request.setAttribute("name","purchase");
	         request.getRequestDispatcher("purchasedescription.jsp?type="+ "construction").forward(request, response);
	}
		     else if ("construction".equals(q)) {
		    	 request.setAttribute("name","construction");
		    	 request.getRequestDispatcher("constructiondescription.jsp?type="+ "construction").forward(request, response);
		      }
		      else if ("extension".equals(q)) {
		    	  request.setAttribute("name","extension");
		    	  request.getRequestDispatcher("extensiondescription.jsp?type="+ "extention").forward(request, response);
	   }
	      
		     else if ("renovation".equals(q)) 
		     {
		    	 request.setAttribute("name","renovation");
		    	 request.getRequestDispatcher("renovationdescription.jsp?type="+ "renovation").forward(request, response);
		     }
	}

}
