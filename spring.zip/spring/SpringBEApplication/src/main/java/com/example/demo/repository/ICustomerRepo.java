package com.example.demo.repository;
import org.springframework.data.repository.CrudRepository;

import com.example.demo.beans.Customer;
public interface ICustomerRepo extends CrudRepository<Customer,Integer>{

}
