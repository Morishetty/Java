package com.example.demo.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.beans.Customer;

@Service
public interface ICustomerService {
public List<Customer> getAll();

public void addCustomer(Customer c);

void updateCustomer(int id, Customer c, String mailid, String city);
}
