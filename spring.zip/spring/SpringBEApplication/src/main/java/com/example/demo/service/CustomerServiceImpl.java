package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.beans.Customer;
import com.example.demo.repository.ICustomerRepo;

@Component
public class CustomerServiceImpl implements ICustomerService{
@Autowired
ICustomerRepo repo;
List<Customer> list=new ArrayList();
	@Override
	public List<Customer> getAll() {
		repo.findAll().forEach(list::add);
		return list;
	}
	@Override
	public void addCustomer(Customer c) {
	repo.save(c);
	}
	@Override
	public void updateCustomer(int id, Customer c, String mailid, String city) {
		if(repo.findOne(id) != null)
		{
			c.setMailid(mailid);
			c.setCity(city);
			repo.save(c);
		}
		
	}



}
