package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.beans.Customer;
import com.example.demo.service.ICustomerService;

@RestController
public class CustomerRestController {
@Autowired
ICustomerService service;
@RequestMapping(value="/getAll",method=RequestMethod.GET)
public List<Customer> getAll()
{
	return service.getAll();
}
@RequestMapping(value="/addp",method=RequestMethod.POST)
public String addCustomer(@RequestBody Customer c)
{
	 service.addCustomer(c);
	 return "Success";
}
@RequestMapping(value="/update",method=RequestMethod.POST)
public String updateCustomer(@RequestParam("id")int id,@RequestParam("cus") Customer cus,@RequestParam("mailid")String mailid,@RequestParam("city")String city)
{
	 service.updateCustomer(id,cus,mailid,city);
	 return "Success";
}
}
