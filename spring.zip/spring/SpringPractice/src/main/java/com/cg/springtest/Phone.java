package com.cg.springtest;
import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.security.auth.Destroyable;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
public class Phone implements InitializingBean,DisposableBean{
private String brand;
private double price;
public String getBrand() {
	return brand;
}
public void setBrand(String brand) {
	this.brand = brand;
}
public double getPrice() {
	return price;
}
public void setPrice(double price) {
	this.price = price;
}
public Phone(String brand, double price) {
	super();
	this.brand = brand;
	this.price = price;
}
@Override
public String toString() {
	return "Phone [brand=" + brand + ", price=" + price + "]";
}
public void afterPropertiesSet() throws Exception {
	
	System.out.println("By Implementing Interfaces Init Method");
}
public void destroy() throws Exception {
	System.out.println("By Implementing Interfaces Destroy Method");
	
}
@PostConstruct
public void PostConstruct()
{
	System.out.println("Iam Init Method Using Annotations");
}
@PreDestroy
public void PreDestroy()
{
	
	System.out.println("Iam Destroy From Annotations");
} 
public void init()
{
	System.out.println("Iam Init Method From XML");
}
public void destroyBean()
{
	System.out.println("Iam Destroy Method From XML");
}
}
