package com.cg.springtest;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
public class PhoneMain {
public static void main(String[] args) {
		ConfigurableApplicationContext context=new ClassPathXmlApplicationContext("test.xml");
	Phone p=context.getBean(Phone.class);
		//p.setBrand("Honor 7x");
       // p.setPrice(13000);
        System.out.println(p);
        context.close();
	}

}
