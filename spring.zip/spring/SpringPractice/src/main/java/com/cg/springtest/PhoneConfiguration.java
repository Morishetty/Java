package com.cg.springtest;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
@Configuration
@ComponentScan(basePackages="com.cg.springtest")
public class PhoneConfiguration {
@Bean
public Phone getPhone()
{
	Phone p=new Phone("Samsung",20000);
	return p;
}
}