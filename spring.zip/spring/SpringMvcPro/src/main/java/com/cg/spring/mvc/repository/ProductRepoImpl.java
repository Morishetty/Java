package com.cg.spring.mvc.repository;
import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Component;
import com.cg.spring.mvc.beans.Product;
@Component // spring creates a bean
public class ProductRepoImpl implements IProductRepo{
	List<Product> list=new ArrayList<Product>();
public List<Product> getAllProducts() {
		return list;
	}
public void add(Product p) {
   /* Product p1=new Product();
	p1.setId(list.size()+1);
	p1.setName("iPhone 8s");
	p1.setPrice(85000);
	list.add(p1);
	Product p2=new Product();
	p2.setId(list.size()+1);
	p2.setName("Honor 6x");
	p2.setPrice(13000);
	list.add(p2);*/
	p.setId(list.size()+1);
	list.add(p);
	
}
public Product searchById(int id) {
	for(Product p:list)
	{
		if(p.getId()==id)
		{
			return p;
		}
	}
	return null;
}

}
