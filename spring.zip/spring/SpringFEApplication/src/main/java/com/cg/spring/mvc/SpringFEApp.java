package com.cg.spring.mvc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages="com.cg.spring.mvc")
public class SpringFEApp {

	public static void main(String[] args) {
		
SpringApplication.run(SpringFEApp.class,args);
	}

}
