package com.cg.spring.mvc.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.cg.spring.mvc.beans.Employee;
import com.cg.spring.mvc.repository.IEmployeeRepo;
@Component
public class IEmployeeServiceImpl implements IEmployeeService{
@Autowired
IEmployeeRepo repo;
	public void addEmployeeDetails(Employee e) {
		repo.addEmployeeDetails(e);
}
	public List<Employee> getEmployeeDetails() {
		
		return repo.getEmployeeDetails();
	}
	public Employee updateEmployee(int id,double salary) {
		return repo.updateEmployee(id,salary);
	}

}
