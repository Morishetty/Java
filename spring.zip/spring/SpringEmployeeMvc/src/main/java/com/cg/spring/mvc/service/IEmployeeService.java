package com.cg.spring.mvc.service;
import java.util.List;
import org.springframework.stereotype.Service;
import com.cg.spring.mvc.beans.Employee;
@Service
public interface IEmployeeService {
void addEmployeeDetails(Employee p);
List<Employee> getEmployeeDetails();
Employee updateEmployee(int id,double salary);
}
