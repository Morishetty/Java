package com.cg.spring.mvc.repository;
import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Component;
import com.cg.spring.mvc.beans.Employee;
@Component
public class IEmployeeRepoImpl implements IEmployeeRepo{
List<Employee> list=new ArrayList();
public void addEmployeeDetails(Employee e) {
		e.setId(list.size()+1);
		list.add(e);
}
public List<Employee> getEmployeeDetails() {
	Employee e=new Employee();
	e.setId(list.size()+1);
	e.setName("Ramya");
	e.setSalary(17000);
	e.setMailid("morishetty@gmail.com");
	list.add(e);
	return list;
}
public Employee updateEmployee(int id,double salary) {
	for(Employee e:list) {
		if(e.getId()==id)
		{
			e.setSalary(salary);
			
		}
	}
return null;
}
}
