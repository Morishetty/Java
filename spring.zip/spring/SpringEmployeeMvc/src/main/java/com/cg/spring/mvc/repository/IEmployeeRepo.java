package com.cg.spring.mvc.repository;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.spring.mvc.beans.Employee;
@Repository
public interface IEmployeeRepo {

	void addEmployeeDetails(Employee e);

	List<Employee> getEmployeeDetails();

	Employee updateEmployee(int id,double salary);

}
