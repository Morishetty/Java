package com.cg.spring.mvc.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.cg.spring.mvc.beans.Employee;
import com.cg.spring.mvc.service.IEmployeeService;
@Controller
public class EmployeeController {
@Autowired
IEmployeeService service;
@RequestMapping(value="/getAll",method=RequestMethod.GET)
public ModelAndView getEmployeeDetails()
{
	ModelAndView mv=new ModelAndView("show");
	mv.addObject("employee",service.getEmployeeDetails());
	return mv;
}
@RequestMapping(value="/addemployee",method=RequestMethod.GET)
public ModelAndView addEmployee()
{
	ModelAndView mv=new ModelAndView("add");
	mv.addObject("command", new Employee());
	return mv;
}
@RequestMapping(value="/addemployeedetails",method=RequestMethod.POST)
public String addEmployeeDetails(Employee p)
{
	service.addEmployeeDetails(p);
	return "redirect:/getAll";
}
@RequestMapping(value="/updateemployee",method=RequestMethod.GET)
public ModelAndView updateEmployee()
{
	ModelAndView mv=new ModelAndView("update");
	mv.addObject("command",new Employee());
	return mv;
}
@RequestMapping(value="/update",method=RequestMethod.POST)
public String update(@RequestParam("id") int id,@RequestParam("salary") double salary)
{
	service.updateEmployee(id,salary);
	return "Successfully Updated";
	
}
}
