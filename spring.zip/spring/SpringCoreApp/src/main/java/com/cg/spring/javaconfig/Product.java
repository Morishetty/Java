package com.cg.spring.javaconfig;
public class Product {
private String productname;
private double productprice;
public Product(String productname, double productprice) {
	super();
	this.productname = productname;
	this.productprice = productprice;
}
public Product()
{
	
}
public String getProductname() {
	return productname;
}

public void setProductname(String productname) {
	this.productname = productname;
}

public double getProductprice() {
	return productprice;
}

public void setProductprice(double productprice) {
	this.productprice = productprice;
}

@Override
public String toString() {
	return "Product [productname=" + productname + ", productprice=" + productprice + "]";
}

}
