package com.cg.spring.core;
public class Manager {
private int deptno;
private String pname;
private int pcode;
public int getDeptno() {
	return deptno;
}
public void setDeptno(int deptno) {
	this.deptno = deptno;
}
public String getPname() {
	return pname;
}
public void setPname(String pname) {
	this.pname = pname;
}
public int getPcode() {
	return pcode;
}
public void setPcode(int pcode) {
	this.pcode = pcode;
}
@Override
public String toString() {
	return "Manager [deptno=" + deptno + ", pname=" + pname + ", pcode=" + pcode + "]";
}

}
