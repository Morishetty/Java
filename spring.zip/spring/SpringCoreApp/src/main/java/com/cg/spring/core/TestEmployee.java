package com.cg.spring.core;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
public class TestEmployee {
public static void main(String[] args)
{
//Creating ApplicationContext Container to load configuration file(spring.xml) which creates a bean instance
ConfigurableApplicationContext context =new ClassPathXmlApplicationContext("spring.xml");
//Two ways for passing class
// 1.Employee e=(Employee)context.getBean("emp");
//2.
Employee e=context.getBean(Employee.class);
Manager m=context.getBean(Manager.class);
System.out.println(e);
System.out.println(m);
context.close();
}
}
