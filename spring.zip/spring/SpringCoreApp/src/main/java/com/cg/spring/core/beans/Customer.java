package com.cg.spring.core.beans;
import java.util.List;
import java.util.Set;
public class Customer {
private String firstname;
private String lastname;
private Address addr;
Set <Address> set;
public Set<Address> getSet() {
	return set;
}
public void setSet(Set<Address> set) {
	this.set = set;
}
public String getFirstname() {
	return firstname;
}
public void setFirstname(String firstname) {
	this.firstname = firstname;
}
public String getLastname() {
	return lastname;
}
public void setLastname(String lastname) {
	this.lastname = lastname;
}
public Address getAddr() {
	return addr;
}
public void setAddr(Address addr) {
	this.addr = addr;
}
@Override
public String toString() {
	return "Customer [firstname=" + firstname + ", lastname=" + lastname + ", addr=" + addr + ", set=" + set + "]";
}
public Customer(String firstname, String lastname, Address addr) {
	super();
	this.firstname = firstname;
	this.lastname = lastname;
	this.addr = addr;
}
public Customer()
{
	
}
}
