package com.cg.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.loandao.LoanDAO;

/**
 * Servlet implementation class AdminValidation
 */
@WebServlet("/AdminValidation")
public class AdminValidation extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		LoanDAO dao=new LoanDAO();
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String id=request.getParameter("name");
		String password=request.getParameter("pass");
		if(id.equals("2030") && password.equals("admin123"))
				{
			Connection con=null;
			PreparedStatement ps=null;
			try {
				Class.forName("oracle.jdbc.driver.OracleDriver");
				String url="jdbc:oracle:thin:@localhost:1521:XE";
				String user="system";
				String pass="Capgemini123";
				con=DriverManager.getConnection(url,user,pass);
				String sql="select * from loanapplication where status=?";
				ps=con.prepareStatement(sql);
				ps.setString(1,"accepted");
				ResultSet rs=ps.executeQuery();
				out.println("---------------------From Loan Application-------------------------");
				while(rs.next())
				{
					out.println("<html>");
					out.println("<body>");
					out.println("<p>" + rs.getString(1) + "&nbsp;" + rs.getString(2)+ rs.getString(3) +rs.getString(4) + rs.getString(5)+ rs.getString(6)+rs.getString(7)+rs.getString(8)+rs.getString(9)+rs.getString(10) +rs.getString(11) + "</p>");
					out.println("</body></html>");
					
				}
						
			} catch (Exception e) {
				e.printStackTrace();
			}
				
				}
	else
	{ 
		out.println("Sorry");
	}
	}

}
