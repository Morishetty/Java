package com.cg.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class FinanceServlet
 */
@WebServlet("/FinanceServlet")
public class FinanceServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 PrintWriter out=response.getWriter();
		String q2 = request.getParameter("radio");
		      if ("Customer".equals(q2)) {
		    	response.sendRedirect("view.jsp");
	}
		      else if ("Lad".equals(q2)) {
				    	response.sendRedirect("login.jsp");
		      }
		      else if("Administrator".equals(q2))
		      {
		    	  response.sendRedirect("login.jsp");
		      }
		     // String q = request.getParameter("radio");
		     // if ("purchase".equals(q)) {
			    	//response.sendRedirect("purchase.jsp");
		//}
			     // else if ("construction".equals(q)) {
					    	//response.sendRedirect("construction.jsp");
			     /// }
			      //else if ("extension".equals(q)) {
				    	//response.sendRedirect("extension.jsp");
		   //   }//
		      
			     // else
			     // {
			    //	  response.sendRedirect("renovation.jsp");
			     // }
}
	
}